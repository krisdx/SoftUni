namespace VehicleParkSystem.Interfaces
{
    public interface IVehicleParkSystemEngine
    {
        void Run();
    }
}