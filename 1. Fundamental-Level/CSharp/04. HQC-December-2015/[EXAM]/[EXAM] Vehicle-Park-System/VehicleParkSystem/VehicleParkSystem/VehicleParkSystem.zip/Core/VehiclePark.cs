﻿namespace VehicleParkSystem.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using VehicleParkSystem.Data;
    using VehicleParkSystem.Interfaces;
    using VehicleParkSystem.Models;
    using VehicleParkSystem.Models.Vehicles;

    public class VehiclePark : IVehiclePark
    {
        private readonly Layout layout;
        private readonly VehicleParkSystemData vehicleParkSystemData;

        public VehiclePark(int numberOfSectors, int placesPerSector)
        {
            this.layout = new Layout(numberOfSectors, placesPerSector);
            this.vehicleParkSystemData = new VehicleParkSystemData(numberOfSectors);
        }

        public string InsertCar(Car car, int sector, int placeNumber, DateTime startTime)
        {
            return this.InsertVehicle(car, sector, placeNumber, startTime);
        }

        public string InsertTruck(Truck truck, int sector, int placeNumber, DateTime startTime)
        {
            return this.InsertVehicle(truck, sector, placeNumber, startTime);
        }

        public string InsertMotorbike(Motorbike motorbike, int sector, int placeNumber, DateTime startTime)
        {
            return this.InsertVehicle(motorbike, sector, placeNumber, startTime);
        }

        public string ExitVehicle(string licensePlate, DateTime endOfParking, decimal money)
        {
            if (!this.vehicleParkSystemData.VehiclesByLicensePlate.ContainsKey(licensePlate))
            {
                // TODO: Extract all messages in utility class - constansts.
                return string.Format("There is no vehicle with license plate {0} in the park", licensePlate);
            }

            var vehicle = this.vehicleParkSystemData.VehiclesByLicensePlate[licensePlate];

            var startTime = this.vehicleParkSystemData.VehiclesByStartTime[vehicle];
            int endTime = (int)(endOfParking - startTime).TotalHours;

            var ticket = new StringBuilder();

            decimal regularRate = vehicle.ReservedHours * vehicle.RegularRate;
            decimal overTimeRate = endTime > vehicle.ReservedHours ?
                 (endTime - vehicle.ReservedHours) * vehicle.OvertimeRate : 0;

            ticket.AppendLine(new string('*', 20))

                .AppendFormat("{0}", vehicle).AppendLine()
                .AppendFormat("at place {0}", this.vehicleParkSystemData.VehiclesInParkPlaces[vehicle])

                .AppendLine()
                .AppendFormat("Rate: ${0:F2}", regularRate)
                .AppendLine()

                .AppendFormat("Overtime rate: ${0:F2}", overTimeRate)

                .AppendLine()
                .AppendLine(new string('-', 20))

                .AppendFormat("Total: ${0:F2}", regularRate + overTimeRate)

                .AppendLine()
                .AppendFormat("Paid: ${0:F2}", money)

                .AppendLine()
                .AppendFormat("Change: ${0:F2}", money - (regularRate + overTimeRate))

                .AppendLine()
                .Append(new string('*', 20));

            this.vehicleParkSystemData.RemoveVehicle(vehicle);

            return ticket.ToString();
        }

        public string GetStatus()
        {
            var places = this.vehicleParkSystemData
                .SpacesCount
                .Select((vehiclesParked, sectorIndex) => string.Format(
                    "Sector {0}: {1} / {2} ({3}% full)",
                    sectorIndex + 1,
                    vehiclesParked,
                    this.layout.PlacesPerSector,
                    Math.Round((double)vehiclesParked / this.layout.PlacesPerSector * 100)));

            return string.Join(Environment.NewLine, places);
        }

        public string FindVehicle(string licensePlate)
        {
            if (!this.vehicleParkSystemData.VehiclesByLicensePlate.ContainsKey(licensePlate))
            {
                return string.Format("There is no vehicle with license plate {0} in the park", licensePlate);
            }

            var vehicle = this.vehicleParkSystemData.VehiclesByLicensePlate[licensePlate];

            return this.Input(new[] { vehicle });
        }

        public string FindVehiclesByOwner(string owner)
        {
            bool hasAnyVehicles = this.vehicleParkSystemData
                .ParkPlaces.Values
                .Any(vehicle => vehicle.Owner == owner);

            if (!hasAnyVehicles)
            {
                return "No vehicles by " + owner;
            }

            var vehiclesByOwner = this.vehicleParkSystemData
                .ParkPlaces.Values
                .Where(vehicle => vehicle.Owner == owner);

            var orderedVehiclesByOwner = vehiclesByOwner
                .OrderBy(vehicle => this.vehicleParkSystemData.VehiclesByStartTime[vehicle])
                .ThenBy(vehicle => vehicle.LicensePlate)
                .ToList();

            //Console.WriteLine(this.Input(orderedVehiclesByOwner));
            //return string.Join(Environment.NewLine, this.Input(orderedVehiclesByOwner));
            return this.Input(orderedVehiclesByOwner);
        }

        // TODO: Rename method
        private string Input(IEnumerable<IVehicle> vehicles)
        {
            var a = vehicles
                .Select(vehicle => string.Format("{0}{1}Parked at {2}",
                    vehicle.ToString(),
                    Environment.NewLine,
                    this.vehicleParkSystemData.VehiclesInParkPlaces[vehicle]));

            return string.Join(Environment.NewLine, a);
        }

        private string InsertVehicle(IVehicle vehicle, int sector, int placeNumber, DateTime startTime)
        {
            if (sector > this.layout.NumberOfSectors)
            {
                return string.Format("There is no sector {0} in the park", sector);
            }

            if (placeNumber > this.layout.PlacesPerSector)
            {
                return string.Format("There is no place {0} in sector {1}", placeNumber, sector);
            }

            if (this.vehicleParkSystemData.ParkPlaces.ContainsKey(string.Format("({0},{1})", sector, placeNumber)))
            {
                return string.Format("The place ({0},{1}) is occupied", sector, placeNumber);
            }

            if (this.vehicleParkSystemData.VehiclesByLicensePlate.ContainsKey(vehicle.LicensePlate))
            {
                return string.Format("There is already a vehicle with license plate {0} in the park", vehicle.LicensePlate);
            }

            this.vehicleParkSystemData.InsertVehicle(vehicle, sector, placeNumber, startTime);

            return string.Format("{0} parked successfully at place ({1},{2})", vehicle.GetType().Name, sector, placeNumber);
        }
    }
}