package problem9_Google;

public class Child extends Relative {
    public Child(String name, String birthday) {
        super(name, birthday);
    }
}
