package problem9_Google;

public class Parent extends Relative{
    public Parent(String name, String birthday) {
        super(name, birthday);
    }
}
