package problem10_11_12_13_InfernoInfinity.contracts.IO;

public interface Printable {

    void print(String message);

    void printLine(String message);

    void displayException(String exceptionMessage);
}