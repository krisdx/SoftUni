package problem10_11_12_13_InfernoInfinity.contracts.models;

public interface Gem {
    int getStrength();

    int getAgility();

    int getVitality();
}