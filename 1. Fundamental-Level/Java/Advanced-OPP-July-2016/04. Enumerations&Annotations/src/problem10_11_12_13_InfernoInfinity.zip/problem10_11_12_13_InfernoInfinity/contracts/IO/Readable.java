package problem10_11_12_13_InfernoInfinity.contracts.IO;

import java.io.IOException;

public interface Readable {
    String read() throws IOException;
}