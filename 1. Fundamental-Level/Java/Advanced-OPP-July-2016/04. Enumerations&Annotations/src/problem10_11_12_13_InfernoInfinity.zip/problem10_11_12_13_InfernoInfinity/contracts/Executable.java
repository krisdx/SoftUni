package problem10_11_12_13_InfernoInfinity.contracts;

public interface Executable {
    void execute(String[] args);
}